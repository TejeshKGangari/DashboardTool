<?php 
//session_start();
mysql_connect("localhost","dsr","XBU3YbNdNKGfTsbZ") or die(mysql_error());

mysql_select_db("dsr") or die(mysql_error());


?>